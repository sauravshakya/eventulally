<!DOCTYPE html>
<html>
<head>
	<title>home</title>
</head>
<body>
	<h1>calendar</h1>
	<div id="calendar"></div>

</body>
</html><?php /**PATH C:\Users\saurav shakya\eventually\resources\views/home.blade.php ENDPATH**/ ?>